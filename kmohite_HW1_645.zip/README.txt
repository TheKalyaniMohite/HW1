README file

Name: Kalyani Kishor Mohite
G Number: G01460029
Email: Kmohite@gmu.edu

Part1
step1: Created account at Amazon AWS portal
step2: Sign in at https://console.aws.amazon.com/s3/
step3: From services choose S3 and click on create bucket. 
step4: Check for the region and change it to the closest possible region.
step5: Followed all the steps at https://docs.aws.amazon.com/AmazonS3/latest/userguide/HostingWebsiteOnS3Setup.html for setting up the static environment
step6: Upload index.html and error.html files. 
step7: From properties in the bucket access the website end point link.
step8: link for part1: http://hw1-balancedminds.s3-website-us-east-1.amazonaws.com

Part2:
step1: Sign in at Amazon AWS portal. 
step2: From services choose EC2 and click on launch instance.
step3: Check for the region and change it to the closest possible region.
step4: Choose Ubuntu as AMI and lookout for suitable network settings and configuring storage and all and click on launch instance.
step5: Now connect the launched instance.
Step6: In the console window, run the necessary commands.
step7: A new console window will open where you copy and paste the contents of the survey form file.
step8: Go to the bucket and access the public ipv4 DNS for Student Survey form.
step9: link for part2: http://3.94.117.86/StudentSurvey.html

